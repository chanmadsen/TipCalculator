//
//  TipCalculatorViewController.swift
//  TipCalculator
//
//  Created by Lon Chandler Madsen on 8/16/21.
//

import UIKit

class TipCalculatorViewController: UIViewController {
    //MARK: - Outlets
    

    @IBOutlet weak var totalBillAmoutTextField: UITextField!
    @IBOutlet weak var tipPercentSlider: UISlider!
    @IBOutlet weak var numberOfPeopleSlider: UISlider!
    @IBOutlet weak var tipPercentLabel: UILabel!
    @IBOutlet weak var numberOfPeopleLabel: UILabel!
    @IBOutlet weak var eachPersonAmmountLabel: UILabel!
    @IBOutlet weak var totalBillAfterTipLabel: UILabel!
    
    
    //MARK: - Properties
    
    var tipCalculator = TipCalculator(amountBeforeTax: 0, tipPercentage: 0.10)
    
    //MARK: - lifeCycles
    override func viewDidLoad() {
        super.viewDidLoad()
        totalBillAmoutTextField.delegate = self
        totalBillAmoutTextField.becomeFirstResponder()
    }
    
    
    //MARK: - helperMethods
    
    func calculateBill(){
        tipCalculator.tipPercentage = Double(tipPercentSlider.value) / 100.00
        tipCalculator.amountBeforeTax = (totalBillAmoutTextField.text! as NSString).doubleValue
        tipCalculator.calculateTip()
        updateView()
    }
    
    func updateView(){
        totalBillAfterTipLabel.text = String(format: "$%0.2f", tipCalculator.totalAmount)
        let numberOfPeople: Int = Int(numberOfPeopleSlider.value)
        eachPersonAmmountLabel.text = String(format: "$%0.2f", tipCalculator.totalAmount / Double(numberOfPeople))
    }
    
    //MARK: - Actions
    
    @IBAction func tipSliderValueChanged(_ sender: Any) {
        tipPercentLabel.text = String(format: "Tip: %02d%%", Int(tipPercentSlider.value))
        calculateBill()
    }
    
    @IBAction func numberOfPeopleSliderCHanged(_ sender: Any) {
        numberOfPeopleLabel.text = "Split: \(Int(numberOfPeopleSlider.value))"
        calculateBill()
    }
    
    @IBAction func totalBillTextFieldEC(_ sender: Any) {
        calculateBill()
    }
    
}//End of class

extension TipCalculatorViewController: UITextFieldDelegate {
    func textFieldDidEndEditing(_ textField: UITextField) {
        calculateBill()
    }
}
